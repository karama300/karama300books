# A TUTORIAL ON POINTERS AND ARRAYS IN C

This is A TUTORIAL ON POINTERS AND ARRAYS IN C Version 1.3 by Ted Jensen. I am putting this up on my Github account as it appears that Ted has taken down his website where this tutorial was located. I find this tutorial on pointers in C to be one of the best out there and well worth preserving. Since Ted also put this in the Public Domain I plan on working on the tutorial to remove any links to his defunct website and point them to this repository. I also plan on cleaning up the tutorial a bit to remove a few 1990's references (when this turtorial was written) and if needed, update any code to the C11 standard.

The first commit was exactly as ver. 1.2 of his tutorial on his website before it was deleted.
*   [Download](https://github.com/jflaherty/ptrtut13/archive/v1.2.zip) it as a set of HTML/PDF pages compressed to a ZIP File.
*   [Download](https://github.com/jflaherty/ptrtut13/archive/v1.2.tar.gz) it as a set of HTML/PDF pages compressed to a GZIP archive.

This is ver 1.3 and available to browse online.
*   You can [Read it Online](md/pointers.md)
*   [Download](https://github.com/jflaherty/ptrtut13/archive/v1.3.zip) it as a set of HTML/MD/PDF pages compressed to a ZIP File.
*   [Download](https://github.com/jflaherty/ptrtut13/archive/v1.3.tar.gz) it as a set of HTML/MD/PDF pages compressed to a GZIP archive. 
